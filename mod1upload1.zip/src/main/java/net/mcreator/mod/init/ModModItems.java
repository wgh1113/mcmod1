
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.item.Item;

import net.mcreator.mod.item.FireProofLeatherItem;
import net.mcreator.mod.item.CoolingGelItem;
import net.mcreator.mod.item.BlazeswordItem;
import net.mcreator.mod.item.BlazeironItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item BLAZEIRON = register(new BlazeironItem());
	public static final Item COOLING_GEL = register(new CoolingGelItem());
	public static final Item FIRE_PROOF_LEATHER = register(new FireProofLeatherItem());
	public static final Item BLAZESWORD = register(new BlazeswordItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
