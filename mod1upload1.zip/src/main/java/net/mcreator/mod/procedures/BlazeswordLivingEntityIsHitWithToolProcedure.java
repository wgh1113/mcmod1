package net.mcreator.mod.procedures;

import net.minecraft.world.entity.Entity;

public class BlazeswordLivingEntityIsHitWithToolProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(5);
	}
}
